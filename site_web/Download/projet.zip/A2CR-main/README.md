# Pac-Man AI

## Description

An AI who try to play to Pac-Man

## Getting Started

### Installing

```
make
```

### Executing program

trainig :
```
./Pac-Man train
```

playing :
```
./Pac-Man train
```
## Authors

* Alexandre Bourcier
* Clément Bruley
* Clément Iliou
* Rémi Monteil
