void init_Qlearning();
char execute_Qlearning(Game *game, int cur_state);
void adjust_Q_tab(int reward);
