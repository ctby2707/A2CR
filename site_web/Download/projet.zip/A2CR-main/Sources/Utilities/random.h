#ifndef RANDOM
#define RANDOM

int random_int(int max);

#endif
