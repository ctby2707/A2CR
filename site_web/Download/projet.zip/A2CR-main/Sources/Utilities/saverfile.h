#ifndef SAVERFILE_H
#define SAVERFILE_H

void savefile(char* path, double* list, int size);
void loadfile(char* path, double* list, int size);

#endif
