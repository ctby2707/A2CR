#ifndef MAIN_H
#define MAIN_H

#include "Game/game_init.h"

Game *get_game();

#endif
