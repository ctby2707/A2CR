int find_ghosts(int *map, int pos, char dir, int b, int i, int c, int p);
