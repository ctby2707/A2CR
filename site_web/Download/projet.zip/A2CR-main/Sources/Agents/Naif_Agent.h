#ifndef NAIF_AGENT
#define NAIF_AGENT

char Naif_Agent(Game *game);

#endif
