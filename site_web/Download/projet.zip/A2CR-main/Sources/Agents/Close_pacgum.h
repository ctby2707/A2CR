char find_close_pac_gum(int *map, int A, int *dir);
