#ifndef PLAY_H
#define PLAY_H

void play_init();
gboolean play();

#endif
