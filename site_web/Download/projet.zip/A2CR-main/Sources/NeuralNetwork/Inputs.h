#ifndef NEURALNETWORK_INIT_H
#define NEURALNETWORK_INIT_H

double *init_inputs();

#endif
