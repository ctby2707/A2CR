#ifndef LOOP_H
#define LOOP_H

gboolean loop(int interface_on);

#endif
