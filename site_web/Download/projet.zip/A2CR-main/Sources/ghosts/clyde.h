#ifndef CLYDE_H
#define CLYDE_H

char clyde(int me, int pacman, int *map, int prev);

#endif
