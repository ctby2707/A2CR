#ifndef BLINKY_H
#define BLINKY_H

char blinky(int me, int pacman, int *map, int prev);

#endif
