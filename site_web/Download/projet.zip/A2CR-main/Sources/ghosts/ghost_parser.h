#ifndef GHOST_PARSER_H
#define GHOST_PARSER_H

void define_direction(Ghost *pl, char type, Game *game);

#endif
