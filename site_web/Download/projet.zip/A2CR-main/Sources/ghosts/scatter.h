#ifndef SCATTER_H
#define SCATTER_H

void define_scater_mode(Game *game, Ghost *pl);

#endif
