#ifndef INKY_H
#define INKY_H

char inky(int me, int blinky, int dir_pacman, int *map, int prev);

#endif
