#ifndef PINKY_H
#define PINKY_H

char pinky(int me, int pacman, int dir_pacman, int *map, int prev);

#endif
